<?php
include '../koneksi.php';
session_start(); // Start session

function calculateLoyaltyPoints($koneksi) {
    // Fetch all transactions
    $query_transactions = "SELECT id_transaksi, user, item, qty FROM transaksi_sales";
    $result_transactions = mysqli_query($koneksi, $query_transactions);

    if ($result_transactions && mysqli_num_rows($result_transactions) > 0) {
        while ($transaction = mysqli_fetch_assoc($result_transactions)) {
            $id_transaksi = $transaction['id_transaksi'];
            $id_user = $transaction['user'];
            $id_item = $transaction['item'];
            $qty = $transaction['qty'];

            // Fetch product price
            $query_product = "SELECT harga_produk_satuan FROM produk WHERE id_produk = $id_item";
            $result_product = mysqli_query($koneksi, $query_product);
            if ($result_product && mysqli_num_rows($result_product) > 0) {
                $row_product = mysqli_fetch_assoc($result_product);
                $harga_produk_satuan = $row_product['harga_produk_satuan'];

                // Calculate loyalty points for this transaction
                $total_spending = $harga_produk_satuan * $qty;
                $loyalty_points = floor($total_spending / 100000) * 10;

                // Update the transaction with calculated points
                $update_transaction = "UPDATE transaksi_sales SET perolehan_poin = $loyalty_points WHERE id_transaksi = $id_transaksi";
                mysqli_query($koneksi, $update_transaction);
            }
        }
    }

    // Recalculate total loyalty points for each user
    $query_users = "SELECT id_user FROM user";
    $result_users = mysqli_query($koneksi, $query_users);

    if ($result_users && mysqli_num_rows($result_users) > 0) {
        while ($user = mysqli_fetch_assoc($result_users)) {
            $id_user = $user['id_user'];

            // Sum all loyalty points from transactions for this user
            $query_total_points = "SELECT SUM(perolehan_poin) AS total_points FROM transaksi_sales WHERE user = $id_user";
            $result_total_points = mysqli_query($koneksi, $query_total_points);

            if ($result_total_points && mysqli_num_rows($result_total_points) > 0) {
                $row_total_points = mysqli_fetch_assoc($result_total_points);
                $total_points = $row_total_points['total_points'] ?? 0;

                // Update user's total loyalty points
                $update_user_points = "UPDATE user SET poin_loyalty = $total_points WHERE id_user = $id_user";
                mysqli_query($koneksi, $update_user_points);
            }
        }
    }
}

function updateMembershipLevel($koneksi) {
    // Fetch all users from the database
    $query_users = "SELECT id_user FROM user";
    $result_users = mysqli_query($koneksi, $query_users);

    if ($result_users && mysqli_num_rows($result_users) > 0) {
        while ($user = mysqli_fetch_assoc($result_users)) {
            $id_user = $user['id_user'];

            // Calculate total spending for this user
            $query_transactions = "SELECT SUM(produk.harga_produk_satuan * transaksi_sales.qty) AS total_spending 
                                    FROM transaksi_sales 
                                    JOIN produk ON transaksi_sales.item = produk.id_produk 
                                    WHERE transaksi_sales.user = $id_user";
            $result_transactions = mysqli_query($koneksi, $query_transactions);
            $transaction_data = mysqli_fetch_assoc($result_transactions);
            $total_spending = $transaction_data['total_spending'] ?? 0;

            // Determine membership level based on total spending
            if ($total_spending >= 4000000) {
                $membership_level = 'Platinum';
            } elseif ($total_spending >= 3000000) {
                $membership_level = 'Gold';
            } elseif ($total_spending >= 2000000) {
                $membership_level = 'Silver';
            } elseif ($total_spending >= 1000000) {
                $membership_level = 'Bronze';
            } else {
                $membership_level = 'None';
            }

            // Update user's membership level in the database
            $update_user = "UPDATE user 
                            SET membership = '$membership_level' 
                            WHERE id_user = $id_user";
            mysqli_query($koneksi, $update_user);
        }
    }
}

// Get the prize ID from the URL
$id_produk = isset($_GET['id']) ? intval($_GET['id']) : 0;
$id_user = $_SESSION['id_user'];

// Fetch the product details from the 'produk' table
$query_produk = "SELECT nama_produk, harga_produk_satuan FROM produk WHERE id_produk = ?";
$stmt = $koneksi->prepare($query_produk);
$stmt->bind_param("i", $id_produk);
$stmt->execute();
$result_produk = $stmt->get_result();

if ($result_produk->num_rows == 0) {
    echo "Invalid product.";
    exit();
}

$produk = $result_produk->fetch_assoc();
$nama_produk = $produk['nama_produk'];
$harga_produk = $produk['harga_produk_satuan'];

// If form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qty = isset($_POST['qty']) ? intval($_POST['qty']) : 0;

    // Ensure quantity is valid
    if ($qty <= 0) {
        echo "<script>alert('Quantity must be at least 1.'); window.history.back();</script>";
        exit();
    }

    // Insert transaction into 'transaksi_sales' table
    $query_buy = "INSERT INTO transaksi_sales (tgl, user, item, qty) VALUES (NOW(), ?, ?, ?)";
    $stmt_redeem = $koneksi->prepare($query_buy);
    $stmt_redeem->bind_param("iii", $id_user, $id_produk, $qty);
    $stmt_redeem->execute();

    // Call the function to recalculate loyalty points
    calculateLoyaltyPoints($koneksi);
    updateMembershipLevel($koneksi);

    // Show success alert and redirect to the loyalty shop
    echo "<script>
        alert('Congratulations! You have successfully bought {$qty} \"{$nama_produk}\"!!!');
        window.location.href = 'http://localhost/sistem_loyalty/belanja/productShop.php';
    </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Product</title>
    <style>
        *{
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        #container{
            margin: 20px;
        }

        h2, h3{
            text-align: center;
        }

        h3{
            margin-bottom: 50px;
        }

        form{
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            max-width: 500px;
            margin: 0 auto;
            border: 2px solid black;
        }

        form button, a{
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #80BCBD;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        form button:hover, a:hover{
            background-color: #AAD9BB;
        }

        a{
            margin: 20px;
        }
    </style>
    <script>
        function updateQuantity(action) {
            const qtyInput = document.getElementById('qty');
            let qty = parseInt(qtyInput.value);

            if (action === 'increment') {
                qty++;
            } else if (action === 'decrement' && qty > 1) {
                qty--;
            }

            qtyInput.value = qty;
        }
    </script>
</head>
<body>
    <h2>Buy Product: <?= htmlspecialchars($nama_produk) ?></h2>
    <h3>Price: <?= htmlspecialchars($harga_produk) ?> rupiah per unit</h3>
    <a href="http://localhost/sistem_loyalty/belanja/productShop.php" class="button">Kembali</a>
    <div id="container">
    <form method="POST">
        <label for="qty">Quantity:</label>
        <div>
            <button type="button" onclick="updateQuantity('decrement')">-</button>
            <input type="number" id="qty" name="qty" value="1" min="1" readonly>
            <button type="button" onclick="updateQuantity('increment')">+</button>
        </div>
        <br>
        <button type="submit">Buy</button>
    </form>
    </div>
</body>
</html>
