<?php
include "../koneksi.php";
session_start(); // Mulai session

// Check if the user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: http://localhost/sistem_loyalty/index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman CRM</title>
    <style>
        *{
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container{
            margin: 20px;
        }

        h2 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th {
            background-color: #f2f2f2;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }
    
        a.button {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #80BCBD;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        a.button:hover {
            background-color: #AAD9BB;
        }

        #overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 9998;
        }
        #loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            text-align: center;
            color: white;
            font-size: 24px;
            padding-top: 20%;
        }
    </style>
    <script>
        function showLoading() {
            document.getElementById('overlay').style.display = 'block';
            document.getElementById('loading').style.display = 'block';
        }
    </script>
</head>
<body>
<div id="overlay"></div>
<div id="loading">Processing your request, please wait...</div>
<div class="container">
    <h2>Halaman CRM</h2>
    <a href="http://localhost/sistem_loyalty/homePage.php" class="button">Kembali</a>
    <table border='1'>
        <tr>
            <th>Username</th>
            <th>Item</th>
            <th>Total Transaksi</th>
            <th>Poin Loyalty</th>
            <th>Action</th>
        </tr>
        <?php
        $query = "SELECT user.id_user, user.username, user.poin_loyalty, 
        GROUP_CONCAT(produk.nama_produk) AS purchased_items, 
        COUNT(ts.item) AS purchase_count, 
        SUM(produk.harga_produk_satuan * ts.qty) AS total_spending
        FROM user 
        JOIN transaksi_sales ts ON user.id_user = ts.user
        JOIN produk ON produk.id_produk = ts.item 
        GROUP BY user.id_user
        ORDER BY purchase_count DESC";
        $result = mysqli_query($koneksi, $query);

        if(!$result){
            echo "query gagal!";
        } 
        else{
            while($row = mysqli_fetch_assoc($result)){
                echo "<tr>
                        <td>".$row['username']."</td>
                        <td>".$row['purchased_items']."</td>
                        <td>".$row['total_spending']."</td>
                        <td>".$row['poin_loyalty']." points</td>
                        <td>
                            <a href='http://localhost/sistem_loyalty/crm/send_mail.php?id_user=".$row['id_user']."' class='button' onclick='showLoading()'>Mail</a>
                        </td>
                      </tr>";
            }
        }
        ?>
    </table>
</div>
</body>
</html>
