<?php
include "../koneksi.php";
$id = $_GET['id'];

try {
    $query = "DELETE FROM transaksi_sales WHERE id_transaksi = '$id'";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        throw new Exception("Data gagal dihapus!");
    } else {
        echo "Data berhasil dihapus!";
        header("Location: http://localhost/sistem_loyalty/data_transaksi_belanja/read.php");
    }
} catch (Exception $e) {
    echo "Invalid operation! Ada data di tabel child yang terhubung!";
}
?>
